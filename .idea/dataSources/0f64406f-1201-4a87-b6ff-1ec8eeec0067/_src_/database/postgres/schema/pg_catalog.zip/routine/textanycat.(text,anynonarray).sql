create function textanycat(text, anynonarray) returns text
STABLE
LANGUAGE SQL
AS $$
select $1 || $2::pg_catalog.text
$$;
